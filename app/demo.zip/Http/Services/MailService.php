<?php

namespace App\Http\Services;

use Illuminate\Support\Facades\Mail;

class MailService
{
    
}
